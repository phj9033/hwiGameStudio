/* ============================================
   Grid Manager - 4x5 Grid System
   ============================================ */
const Grid = (() => {
  const COLS = 4;
  const ROWS = 5;
  const SIZE = COLS; // kept for lockRow/lockCol compat
  const cells = [];
  const cellStates = []; // { enemy: null | { type, hitsLeft, hideTimer, spawnTime }, frozen: false }
  let container = null;

  function init() {
    container = document.getElementById('grid-container');
    container.innerHTML = '';
    cells.length = 0;
    cellStates.length = 0;

    for (let row = 0; row < ROWS; row++) {
      for (let col = 0; col < COLS; col++) {
        const cell = document.createElement('div');
        cell.className = 'cell';
        cell.dataset.row = row;
        cell.dataset.col = col;
        cell.dataset.index = row * COLS + col;
        container.appendChild(cell);
        cells.push(cell);
        cellStates.push({ enemy: null, frozen: false, frozenTimer: null });
      }
    }
  }

  function getCell(index) { return cells[index]; }
  function getState(index) { return cellStates[index]; }
  function getCellCount() { return COLS * ROWS; }

  function getEmptyCells() {
    const empty = [];
    for (let i = 0; i < cells.length; i++) {
      if (!cellStates[i].enemy && !cellStates[i].frozen) empty.push(i);
    }
    return empty;
  }

  function getAdjacentCells(index) {
    const row = Math.floor(index / COLS);
    const col = index % COLS;
    const adj = [];
    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        if (dr === 0 && dc === 0) continue;
        const nr = row + dr, nc = col + dc;
        if (nr >= 0 && nr < ROWS && nc >= 0 && nc < COLS) {
          adj.push(nr * COLS + nc);
        }
      }
    }
    return adj;
  }

  function spawnEnemy(index, enemyType) {
    const cell = cells[index];
    const state = cellStates[index];
    if (state.enemy || state.frozen) return false;

    const emoji = Skins.getEnemyEmoji(enemyType.id);
    const enemyEl = document.createElement('div');
    enemyEl.className = 'enemy';
    enemyEl.textContent = emoji;
    cell.appendChild(enemyEl);

    // Add type class
    cell.classList.add('has-enemy', enemyType.cssClass);

    // HP pips for multi-hit enemies
    if (enemyType.id === 'giant' || enemyType.id === 'armor') {
      const hits = enemyType.hitsRequired || (enemyType.id === 'giant' ? 3 : 2);
      const pips = document.createElement('div');
      pips.className = 'hp-pips';
      for (let i = 0; i < hits; i++) {
        const pip = document.createElement('div');
        pip.className = 'hp-pip';
        pips.appendChild(pip);
      }
      cell.appendChild(pips);
    }

    const duration = enemyType.minTime + Math.random() * (enemyType.maxTime - enemyType.minTime);

    state.enemy = {
      type: enemyType,
      hitsLeft: enemyType.hitsRequired || 1,
      spawnTime: Date.now(),
      duration: duration * 1000,
      element: enemyEl
    };

    // Auto-hide timer
    state.enemy.hideTimer = setTimeout(() => {
      hideEnemy(index, false);
    }, duration * 1000);

    return true;
  }

  function hideEnemy(index, wasHit) {
    const state = cellStates[index];
    const cell = cells[index];
    if (!state.enemy) return null;

    const enemyType = state.enemy.type;
    clearTimeout(state.enemy.hideTimer);

    const enemyEl = state.enemy.element;
    if (wasHit) {
      // Hit: short animation then cleanup
      enemyEl.classList.add('hit');
      setTimeout(() => {
        cell.innerHTML = '';
        cell.className = 'cell';
        if (state.frozen) cell.classList.add('frozen');
      }, 200);
    } else {
      // Time expired: remove immediately to prevent ghost taps
      cell.innerHTML = '';
      cell.className = 'cell';
      if (state.frozen) cell.classList.add('frozen');
    }

    const result = { type: enemyType, wasHit };
    state.enemy = null;
    return result;
  }

  function hitEnemy(index) {
    const state = cellStates[index];
    if (!state.enemy) return null;

    state.enemy.hitsLeft--;

    if (state.enemy.hitsLeft <= 0) {
      return hideEnemy(index, true);
    }

    // Partial hit (armor/giant) - update HP pips
    const cell = cells[index];
    if (state.enemy.type.id === 'armor') {
      cell.classList.add('cracked');
      Audio.sfx.armorHit();
    }
    if (state.enemy.type.id === 'armor' || state.enemy.type.id === 'giant') {
      const pips = cell.querySelectorAll('.hp-pip');
      const depleted = (state.enemy.type.hitsRequired || 1) - state.enemy.hitsLeft;
      for (let i = 0; i < depleted; i++) {
        if (pips[i]) pips[i].classList.add('depleted');
      }
    }
    return { type: state.enemy.type, wasHit: false, partial: true };
  }

  function freezeCell(index, duration = 2000) {
    const state = cellStates[index];
    const cell = cells[index];
    if (state.enemy) hideEnemy(index, false);
    state.frozen = true;
    cell.classList.add('frozen');

    if (state.frozenTimer) clearTimeout(state.frozenTimer);
    state.frozenTimer = setTimeout(() => {
      state.frozen = false;
      cell.classList.remove('frozen');
      state.frozenTimer = null;
    }, duration);
  }

  function lockRow(row, duration = 2000) {
    if (row >= ROWS) return;
    for (let col = 0; col < COLS; col++) {
      const idx = row * COLS + col;
      cells[idx].classList.add('row-locked');
      if (cellStates[idx].enemy) hideEnemy(idx, false);
    }
    setTimeout(() => {
      for (let col = 0; col < COLS; col++) {
        cells[row * COLS + col].classList.remove('row-locked');
      }
    }, duration);
  }

  function lockCol(col, duration = 2000) {
    if (col >= COLS) return;
    for (let row = 0; row < ROWS; row++) {
      const idx = row * COLS + col;
      cells[idx].classList.add('col-locked');
      if (cellStates[idx].enemy) hideEnemy(idx, false);
    }
    setTimeout(() => {
      for (let row = 0; row < ROWS; row++) {
        cells[row * COLS + col].classList.remove('col-locked');
      }
    }, duration);
  }

  function showHitEffect(index, type) {
    const cell = cells[index];
    const effect = document.createElement('div');
    effect.className = `hit-effect hit-${type}`;
    cell.appendChild(effect);
    setTimeout(() => effect.remove(), 400);
  }

  function spawnParticles(index, color, count = 6) {
    const cell = cells[index];
    const rect = cell.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;

    for (let i = 0; i < count; i++) {
      const p = document.createElement('div');
      p.className = 'particle';
      p.style.left = cx + 'px';
      p.style.top = cy + 'px';
      p.style.background = color;
      const angle = (Math.PI * 2 / count) * i + Math.random() * 0.5;
      const dist = 15 + Math.random() * 25;
      p.style.setProperty('--px', Math.cos(angle) * dist + 'px');
      p.style.setProperty('--py', Math.sin(angle) * dist + 'px');
      document.getElementById('floating-texts').appendChild(p);
      setTimeout(() => p.remove(), 400);
    }
  }

  function clearAll() {
    for (let i = 0; i < cells.length; i++) {
      const state = cellStates[i];
      if (state.enemy) {
        clearTimeout(state.enemy.hideTimer);
        state.enemy = null;
      }
      if (state.frozenTimer) {
        clearTimeout(state.frozenTimer);
        state.frozenTimer = null;
      }
      state.frozen = false;
      cells[i].innerHTML = '';
      cells[i].className = 'cell';
    }
  }

  function getActiveEnemyCount() {
    return cellStates.filter(s => s.enemy !== null).length;
  }

  // Weight recent spawn positions lower
  const recentSpawns = [];
  function getWeightedEmptyCell() {
    const empty = getEmptyCells();
    if (empty.length === 0) return -1;

    // Filter out recently used cells
    const preferred = empty.filter(i => !recentSpawns.includes(i));
    const pool = preferred.length > 0 ? preferred : empty;
    const idx = pool[Math.floor(Math.random() * pool.length)];

    recentSpawns.push(idx);
    if (recentSpawns.length > 5) recentSpawns.shift();

    return idx;
  }

  return {
    init, getCell, getState, getCellCount, getEmptyCells, getAdjacentCells,
    spawnEnemy, hideEnemy, hitEnemy, freezeCell, lockRow, lockCol,
    showHitEffect, spawnParticles, clearAll, getActiveEnemyCount, getWeightedEmptyCell,
    COLS, ROWS, SIZE
  };
})();
