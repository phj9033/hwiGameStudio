/* ============================================
   SMASH MOLE - Main Game Controller
   ============================================ */
const Game = (() => {
  // State
  let state = 'TITLE'; // TITLE, STAGE_INTRO, PLAYING, PAUSED, RESULT, GAMEOVER, SKIN_SELECT, STAGE_SELECT, ENDLESS
  let currentStage = 1;
  let timeRemaining = 60;
  let timerInterval = null;
  let isEndless = false;
  let endlessScore = 0;
  let endlessKills = 0;
  let tutorialStep = -1;
  let tutorialDone = false;
  let animFrameId = null;
  let totalStageTime = 60;
  let prevTimeRemaining = 60;

  // DOM refs
  const screens = {};
  const ui = {};

  function cacheDOM() {
    ['title-screen','stage-intro','game-screen','pause-screen',
     'result-screen','gameover-screen','skin-screen','stage-select-screen','guide-screen'].forEach(id => {
      screens[id] = document.getElementById(id);
    });

    ui.bossHPFill = document.getElementById('boss-hp-fill');
    ui.bossHPTrail = document.getElementById('boss-hp-trail');
    ui.bossHPCurrent = document.getElementById('boss-hp-current');
    ui.bossHPMax = document.getElementById('boss-hp-max');
    ui.bossPortrait = document.getElementById('boss-portrait');
    ui.stageNum = document.getElementById('hud-stage-num');
    ui.timerValue = document.getElementById('timer-value');
    ui.hudTimer = document.getElementById('hud-timer');
    ui.comboCount = document.getElementById('combo-count');
    ui.comboMultiplier = document.getElementById('combo-multiplier');
    ui.hudCombo = document.getElementById('hud-combo');
    ui.score = document.getElementById('hud-score');
    ui.best = document.getElementById('hud-best');
    ui.gameScreen = document.getElementById('game-screen');
    ui.gridWrapper = document.getElementById('grid-wrapper');
    ui.floatingTexts = document.getElementById('floating-texts');
    ui.screenFlash = document.getElementById('screen-flash');
    ui.tutorialOverlay = document.getElementById('tutorial-overlay');
    ui.tutorialHand = document.getElementById('tutorial-hand');
    ui.tutorialText = document.getElementById('tutorial-text');
    ui.playerName = document.getElementById('player-name');
    ui.leaderboardBody = document.getElementById('leaderboard-body');
    ui.timerBarFill = document.getElementById('timer-bar-fill');
    ui.timerBarTrail = document.getElementById('timer-bar-trail');
  }

  // ---- Screen Management ----
  function showScreen(id) {
    Object.values(screens).forEach(s => s.classList.remove('active'));
    if (screens[id]) screens[id].classList.add('active');
  }

  // ---- Player Name (HubGame user) ----
  function renderPlayerName() {
    if (!ui.playerName) return;
    const name = window.__HUB_USER__?.name || window.__HUB_USER__?.username || '플레이어';
    ui.playerName.textContent = name + '님 환영합니다!';
  }

  // ---- Leaderboard UI ----
  async function renderLeaderboard() {
    if (!ui.leaderboardBody) return;
    const board = await Storage.getLeaderboard(10);
    if (board.length === 0) {
      ui.leaderboardBody.innerHTML = '<div class="lb-empty">아직 기록이 없습니다</div>';
      return;
    }
    ui.leaderboardBody.innerHTML = board.map((r, i) => {
      const rank = i + 1;
      const rankClass = rank <= 3 ? ` lb-top${rank}` : '';
      return `<div class="lb-row${rankClass}">
        <span class="lb-rank">${rank}</span>
        <span class="lb-name">${r.username || '플레이어'}</span>
        <span class="lb-score">${r.value.toLocaleString()}</span>
      </div>`;
    }).join('');
  }

  // ---- Init ----
  async function init() {
    cacheDOM();
    Audio.init();
    await Skins.applySkins();

    await updateTitleScreen();
    bindEvents();
    showScreen('title-screen');

    // Player name with retry (HUB_USER is injected async, 0.1~0.5s delay)
    renderPlayerName();
    setTimeout(renderPlayerName, 300);
    setTimeout(renderPlayerName, 1000);
  }

  async function updateTitleScreen() {
    const save = await Storage.get();
    document.getElementById('title-best-score').textContent = save.highScore.toLocaleString();
    renderLeaderboard();
  }

  // ---- Events ----
  function bindEvents() {
    // Title
    document.getElementById('btn-start').addEventListener('click', async () => {
      Audio.sfx.buttonClick();
      const save = await Storage.get();
      if (save.maxStageCleared >= 15) {
        startEndless();
      } else {
        startStage(await getNextStage());
      }
    });
    document.getElementById('btn-stage-select').addEventListener('click', () => {
      Audio.sfx.buttonClick();
      openStageSelect();
    });
    document.getElementById('btn-skins').addEventListener('click', () => {
      Audio.sfx.buttonClick();
      openSkinScreen();
    });
    document.getElementById('btn-guide').addEventListener('click', () => {
      Audio.sfx.buttonClick();
      openGuide();
    });

    // Stage Select
    document.getElementById('btn-stage-back').addEventListener('click', () => {
      Audio.sfx.buttonClick();
      showScreen('title-screen');
    });

    // Pause
    document.getElementById('btn-pause').addEventListener('click', pauseGame);
    document.getElementById('btn-resume').addEventListener('click', resumeGame);
    document.getElementById('btn-quit').addEventListener('click', quitToMenu);

    // Result
    document.getElementById('btn-next-stage').addEventListener('click', () => {
      Audio.sfx.buttonClick();
      if (currentStage >= 15) { startEndless(); return; }
      startStage(currentStage + 1);
    });
    document.getElementById('btn-retry').addEventListener('click', () => {
      Audio.sfx.buttonClick();
      startStage(currentStage);
    });
    document.getElementById('btn-menu').addEventListener('click', () => {
      Audio.sfx.buttonClick();
      quitToMenu();
    });

    // Game Over
    document.getElementById('btn-go-retry').addEventListener('click', () => {
      Audio.sfx.buttonClick();
      if (isEndless) startEndless();
      else startStage(currentStage);
    });
    document.getElementById('btn-go-menu').addEventListener('click', () => {
      Audio.sfx.buttonClick();
      quitToMenu();
    });

    // Skin tabs
    document.querySelectorAll('.skin-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.skin-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        renderSkinList(tab.dataset.tab);
      });
    });
    document.getElementById('btn-skin-back').addEventListener('click', async () => {
      Audio.sfx.buttonClick();
      showScreen('title-screen');
      await updateTitleScreen();
    });

    // Guide tabs
    document.querySelectorAll('.guide-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.guide-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        renderGuideTab(tab.dataset.gtab);
      });
    });
    document.getElementById('btn-guide-back').addEventListener('click', () => {
      Audio.sfx.buttonClick();
      showScreen('title-screen');
    });

    // Grid clicks
    document.getElementById('grid-container').addEventListener('click', onGridClick);
    document.getElementById('grid-container').addEventListener('touchstart', onGridTouch, { passive: false });

    // Keyboard
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        if (state === 'PLAYING') pauseGame();
        else if (state === 'PAUSED') resumeGame();
      }
    });

    // Prevent long-press context menu on mobile
    document.getElementById('grid-container').addEventListener('contextmenu', e => e.preventDefault());

    // Prevent pinch-zoom on iOS
    document.addEventListener('gesturestart', e => e.preventDefault());

    // iOS address bar resize: force layout recalculation
    window.addEventListener('resize', () => {
      document.documentElement.style.height = window.innerHeight + 'px';
    });
    document.documentElement.style.height = window.innerHeight + 'px';

    // Init audio on first user interaction
    document.addEventListener('click', () => Audio.init(), { once: true });
    document.addEventListener('touchstart', () => Audio.init(), { once: true });
  }

  // ---- Grid Input ----
  let lastTouchTime = 0;
  let isTouchDevice = false;

  function onGridTouch(e) {
    e.preventDefault();
    isTouchDevice = true;

    // Process only first touch (prevent multi-touch)
    const touch = e.touches[0];
    if (!touch) return;

    // Throttle rapid taps to prevent accidental double-hits on same cell
    const now = Date.now();
    if (now - lastTouchTime < 30) return;
    lastTouchTime = now;

    const el = document.elementFromPoint(touch.clientX, touch.clientY);
    if (el && el.classList.contains('cell')) {
      handleCellClick(el);
    } else if (el && el.closest('.cell')) {
      handleCellClick(el.closest('.cell'));
    }
  }

  function onGridClick(e) {
    // Skip click events on touch devices (already handled by touchstart)
    if (isTouchDevice) return;
    const cell = e.target.closest('.cell');
    if (cell) handleCellClick(cell);
  }

  function handleCellClick(cell) {
    if (state !== 'PLAYING') return;
    const index = parseInt(cell.dataset.index);
    const cellState = Grid.getState(index);

    if (cellState.frozen) return;

    // Tutorial intercept
    if (tutorialStep >= 0 && !tutorialDone) {
      handleTutorialClick(index);
      return;
    }

    if (cellState.enemy) {
      const result = Grid.hitEnemy(index);
      if (!result) return;

      if (result.partial) {
        // Partial hit (armor/giant)
        shakeScreen('light');
        return;
      }

      const enemyType = result.type;

      // Handle special onHit effects
      if (enemyType.onHit === 'bombExplode') {
        handleBombHit(index);
        return;
      }
      if (enemyType.onHit === 'comboReset') {
        handleDecoyHit(index);
        return;
      }

      // Successful kill
      const combo = Combo.increment();
      const damage = Boss.calculateDamage(enemyType, combo.multiplier);
      Boss.takeDamage(damage);

      const scorePoints = Score.addKill(enemyType, combo.multiplier);

      // Visual/audio feedback
      if (enemyType.id === 'golden') {
        Audio.sfx.hitGolden();
        Grid.showHitEffect(index, 'golden');
        Grid.spawnParticles(index, '#ffd700', 8);
        flashScreen('golden');
      } else if (enemyType.id === 'crown') {
        Audio.sfx.crown();
        Grid.showHitEffect(index, 'golden');
        Grid.spawnParticles(index, '#ffd700', 12);
        flashScreen('golden');
      } else {
        Audio.sfx.hitCombo(combo.count);
        Grid.showHitEffect(index, 'normal');
        Grid.spawnParticles(index, '#00ff88');
        if (combo.count > 1) flashScreen('hit');
      }

      shakeScreen(combo.count >= 10 ? 'heavy' : 'light');

      // Floating damage text
      showFloatingTextAtCell(index, `-${damage}`, 'damage');
      if (scorePoints > 100) {
        showFloatingTextAtCell(index, `+${scorePoints}`, 'bonus');
      }

      // Special effects
      if (enemyType.onHit === 'timeBonus') {
        timeRemaining = Math.min(timeRemaining + 3, getStageTime() + 30);
        showFloatingTextAtCell(index, '+3s', 'bonus');
        showFloatingTextAtHud(ui.hudTimer, '+3s', 'bonus');
      }
      if (enemyType.onHit === 'freezeArea') {
        Audio.sfx.freeze();
        const adj = Grid.getAdjacentCells(index);
        adj.forEach(i => Grid.freezeCell(i, 2000));
      }
      if (enemyType.onHit === 'splitSpawn') {
        Audio.sfx.split();
        const adj = Grid.getAdjacentCells(index);
        const empties = adj.filter(i => !Grid.getState(i).enemy && !Grid.getState(i).frozen);
        const spawns = empties.slice(0, 2);
        spawns.forEach(i => Grid.spawnEnemy(i, EnemyTypes.mini));
      }
      if (enemyType.onHit === 'magnetBoost') {
        Audio.sfx.magnet();
        Spawner.activateMagnetBoost();
        showFloatingTextAtCell(index, 'MAGNET!', 'penalty');
      }

      // Track stats (fire-and-forget)
      trackKill(enemyType);

      // Combo milestones
      if (combo.count === 5 || combo.count === 10 || combo.count === 20 || combo.count === 30) {
        showFloatingTextAtCell(index, `${combo.count} COMBO!`, 'combo');
      }

      // Update HUD
      updateComboUI(combo);
      updateBossUIInternal();
      updateScoreUI();

      // Check boss dead
      if (Boss.isDead()) {
        handleStageClear();
      }
    } else {
      // Miss
      Audio.sfx.miss();
      Score.addMiss();
      const wasActive = Combo.reset();
      if (wasActive) {
        Audio.sfx.comboBreak();
        showFloatingTextAtCell(index, 'MISS', 'miss');
        showFloatingTextAtHud(ui.hudCombo, 'BREAK!', 'penalty');
      } else {
        showFloatingTextAtCell(index, 'MISS', 'miss');
      }
      Grid.showHitEffect(index, 'miss');
      updateComboUI({ count: 0, multiplier: 1.0 });
    }
  }

  function handleBombHit(index) {
    Audio.sfx.bomb();
    Grid.showHitEffect(index, 'bomb');
    Grid.spawnParticles(index, '#ff1744', 10);
    flashScreen('bomb');
    shakeScreen('heavy');

    const wasActive = Combo.reset();
    if (wasActive) Audio.sfx.comboBreak();

    timeRemaining = Math.max(0, timeRemaining - 5);
    showFloatingTextAtCell(index, '-5s', 'penalty');
    showFloatingTextAtCell(index, 'BOMB!', 'penalty');
    showFloatingTextAtHud(ui.hudTimer, '-5s', 'penalty');
    if (wasActive) showFloatingTextAtHud(ui.hudCombo, 'BREAK!', 'penalty');
    updateComboUI({ count: 0, multiplier: 1.0 });
    updateTimerUI();
  }

  function handleDecoyHit(index) {
    Grid.showHitEffect(index, 'miss');
    Grid.spawnParticles(index, '#9966cc', 6);

    const wasActive = Combo.reset();
    if (wasActive) Audio.sfx.comboBreak();

    showFloatingTextAtCell(index, 'FAKE!', 'penalty');
    if (wasActive) showFloatingTextAtHud(ui.hudCombo, 'BREAK!', 'penalty');
    updateComboUI({ count: 0, multiplier: 1.0 });
  }

  // ---- Missed enemies (healer/crown) ----
  function onEnemyMissed(enemyType) {
    if (enemyType.onMiss === 'bossHeal') {
      Boss.heal(20);
      Audio.sfx.heal();
      showFloatingText('boss', '+20 HP', 'heal');
      updateBossUIInternal();
    } else if (enemyType.onMiss === 'bossHealBig') {
      Boss.heal(30);
      Audio.sfx.heal();
      showFloatingText('boss', '+30 HP', 'heal');
      updateBossUIInternal();
    }
  }

  // Patch Grid.hideEnemy to call onEnemyMissed
  const _origHideEnemy = Grid.hideEnemy;
  Grid.hideEnemy = function(index, wasHit) {
    const state = Grid.getState(index);
    const type = state.enemy?.type;
    const result = _origHideEnemy.call(Grid, index, wasHit);
    if (result && !wasHit && type) {
      onEnemyMissed(type);
    }
    return result;
  };

  // ---- Stage Flow ----
  function startStage(stageNum) {
    isEndless = false;
    currentStage = stageNum;
    const stageData = getStage(stageNum);
    if (!stageData) return;

    // Show intro
    document.getElementById('intro-stage-num').textContent = stageNum;
    document.getElementById('intro-stage-name').textContent = stageData.name;
    document.getElementById('intro-stage-gimmick').textContent = stageData.desc || '';
    document.getElementById('intro-boss-hp').textContent = stageData.bossHP;
    showScreen('stage-intro');
    state = 'STAGE_INTRO';

    setTimeout(() => {
      beginGameplay(stageData);
    }, 2000);
  }

  function startEndless() {
    isEndless = true;
    currentStage = 99;
    endlessScore = 0;
    endlessKills = 0;

    document.getElementById('intro-stage-num').textContent = '∞';
    document.getElementById('intro-stage-name').textContent = 'ENDLESS MODE';
    document.getElementById('intro-stage-gimmick').textContent = '60초 안에 최고 기록에 도전하세요!';
    document.getElementById('intro-boss-hp').textContent = '∞';
    showScreen('stage-intro');
    state = 'STAGE_INTRO';

    setTimeout(() => {
      const fakeStage = {
        bossHP: 999999, time: 60, maxSimultaneous: 6,
        speedMod: 0.45, gimmickRate: 0.28, tutorial: false
      };
      beginGameplay(fakeStage);
    }, 2000);
  }

  async function beginGameplay(stageData) {
    showScreen('game-screen');
    state = 'PLAYING';

    // Init systems
    Grid.init();
    Boss.init(stageData.bossHP);
    Combo.fullReset();
    Score.reset();
    timeRemaining = stageData.time;
    totalStageTime = stageData.time;
    prevTimeRemaining = stageData.time;

    // Update HUD
    ui.stageNum.textContent = isEndless ? '∞' : currentStage;
    if (ui.timerBarFill) ui.timerBarFill.parentElement.style.display = '';
    updateBossUIInternal();
    updateTimerUI();
    updateScoreUI();
    updateComboUI({ count: 0, multiplier: 1.0 });

    // Boss state
    ui.bossPortrait.classList.remove('hurt', 'panic');
    ui.gameScreen.classList.remove('border-warning', 'border-danger');

    // Load best
    const save = await Storage.get();
    ui.best.textContent = save.highScore.toLocaleString();

    // Tutorial for stage 1
    if (stageData.tutorial && !tutorialDone && save.maxStageCleared === 0) {
      startTutorial();
    } else {
      // Start spawner and timer
      Spawner.start(currentStage, stageData, isEndless);
      startTimer();
      startGameLoop();
    }
  }

  // ---- Timer ----
  function startTimer() {
    if (timerInterval) clearInterval(timerInterval);

    timerInterval = setInterval(() => {
      if (state !== 'PLAYING') return;
      timeRemaining = Math.max(0, timeRemaining - 1);
      updateTimerUI();

      if (timeRemaining <= 10 && timeRemaining > 0) {
        Audio.sfx.timerWarning();
      }
      if (timeRemaining <= 0) {
        handleGameOver();
      }
    }, 1000);
  }

  function stopTimer() {
    if (timerInterval) { clearInterval(timerInterval); timerInterval = null; }
  }

  // ---- Game Loop (for combo timeout check) ----
  function startGameLoop() {
    function loop() {
      if (state !== 'PLAYING') { animFrameId = null; return; }

      // Combo timeout
      if (Combo.checkTimeout()) {
        Audio.sfx.comboBreak();
        updateComboUI({ count: 0, multiplier: 1.0 });
      }

      animFrameId = requestAnimationFrame(loop);
    }
    animFrameId = requestAnimationFrame(loop);
  }

  function stopGameLoop() {
    if (animFrameId) { cancelAnimationFrame(animFrameId); animFrameId = null; }
  }

  // ---- Stage End ----
  async function handleStageClear() {
    state = 'RESULT';
    Spawner.stop();
    stopTimer();
    stopGameLoop();
    Grid.clearAll();

    Audio.sfx.stageClear();

    const stageData = getStage(currentStage);
    const totalTime = stageData ? stageData.time : 60;
    const grade = Score.getGrade(true, timeRemaining, totalTime, 0);
    const final = Score.calculateFinal(timeRemaining);

    // Save progress
    const savedData = await Storage.update(d => {
      if (currentStage > d.maxStageCleared) d.maxStageCleared = currentStage;
      if (!d.stageGrades[currentStage] || gradeRank(grade) > gradeRank(d.stageGrades[currentStage])) {
        d.stageGrades[currentStage] = grade;
      }
      if (final.total > d.highScore) d.highScore = final.total;
      d.stats.totalScore += final.total;
      d.stats.noGameOverStreak++;
      if (Combo.getMaxCombo() > d.stats.maxCombo) d.stats.maxCombo = Combo.getMaxCombo();
    });

    // Submit to leaderboard (use cumulative high score, not single stage score)
    await Storage.submitBestScore(savedData.highScore);

    // Check unlocks
    const unlocks = await Skins.checkUnlocks();

    // Show result
    document.getElementById('result-title').textContent = 'STAGE CLEAR!';
    document.getElementById('result-grade').textContent = grade;
    document.getElementById('result-base-score').textContent = final.baseScore.toLocaleString();
    document.getElementById('result-time-bonus').textContent = final.timeBonus.toLocaleString();
    document.getElementById('result-nomiss-bonus').textContent = final.noMissBonus.toLocaleString();
    document.getElementById('result-max-combo').textContent = Combo.getMaxCombo();
    document.getElementById('result-total-score').textContent = final.total.toLocaleString();

    // Unlock notification
    const unlockEl = document.getElementById('result-unlock');
    if (unlocks.length > 0) {
      unlockEl.style.display = '';
      document.getElementById('result-unlock-text').textContent =
        unlocks.map(u => `${u.emoji} ${u.name}`).join(', ') + ' 해금!';
      Audio.sfx.unlock();
    } else {
      unlockEl.style.display = 'none';
    }

    // Next stage button
    const nextBtn = document.getElementById('btn-next-stage');
    if (currentStage >= 15) {
      nextBtn.textContent = 'ENDLESS MODE';
    } else {
      nextBtn.textContent = 'NEXT STAGE';
    }

    showScreen('result-screen');
  }

  async function handleGameOver() {
    state = 'GAMEOVER';
    Spawner.stop();
    stopTimer();
    stopGameLoop();
    Grid.clearAll();

    Audio.sfx.gameOver();

    const bossPercent = Boss.getPercent();
    const grade = Score.getGrade(false, 0, 1, bossPercent);
    const final = Score.calculateFinal(0);

    const savedData = await Storage.update(d => {
      if (final.total > d.highScore) d.highScore = final.total;
      d.stats.totalScore += final.total;
      d.stats.noGameOverStreak = 0;
      if (Combo.getMaxCombo() > d.stats.maxCombo) d.stats.maxCombo = Combo.getMaxCombo();
    });

    // Submit to leaderboard (use cumulative high score, not single stage score)
    await Storage.submitBestScore(savedData.highScore);

    await Skins.checkUnlocks();

    document.getElementById('gameover-grade').textContent = grade;
    document.getElementById('gameover-hp-remaining').textContent = Math.round(bossPercent * 100) + '%';
    document.getElementById('gameover-score').textContent = final.total.toLocaleString();
    document.getElementById('gameover-max-combo').textContent = Combo.getMaxCombo();
    document.getElementById('gameover-enemies-hit').textContent = Score.getEnemiesHit();

    showScreen('gameover-screen');
  }

  // ---- Pause ----
  function pauseGame() {
    if (state !== 'PLAYING') return;
    state = 'PAUSED';
    Audio.sfx.buttonClick();
    screens['pause-screen'].classList.add('active');
  }

  function resumeGame() {
    if (state !== 'PAUSED') return;
    state = 'PLAYING';
    Audio.sfx.buttonClick();
    screens['pause-screen'].classList.remove('active');
    startGameLoop();
  }

  function quitToMenu() {
    state = 'TITLE';
    Spawner.stop();
    stopTimer();
    stopGameLoop();
    Grid.clearAll();
    screens['pause-screen'].classList.remove('active');
    updateTitleScreen();
    showScreen('title-screen');
  }

  // ---- Stage Select ----
  async function openStageSelect() {
    const save = await Storage.get();
    const list = document.getElementById('stage-list');
    list.innerHTML = '';
    Stages.forEach(s => {
      const btn = document.createElement('button');
      btn.className = 'stage-btn';
      if (s.id > save.maxStageCleared + 1) btn.classList.add('locked');
      if (save.stageGrades[s.id]) btn.classList.add('cleared');
      btn.innerHTML = `
        <span class="stage-btn-num">${s.id}</span>
        <span class="stage-btn-name" style="font-size:9px;color:var(--text-dim)">${s.name}</span>
        ${save.stageGrades[s.id] ? `<span class="stage-btn-grade">${save.stageGrades[s.id]}</span>` : ''}
      `;
      btn.addEventListener('click', () => {
        if (s.id <= save.maxStageCleared + 1) {
          Audio.sfx.buttonClick();
          startStage(s.id);
        }
      });
      list.appendChild(btn);
    });
    showScreen('stage-select-screen');
  }

  // ---- Guide Screen ----
  function openGuide() {
    showScreen('guide-screen');
    document.querySelectorAll('.guide-tab').forEach(t => t.classList.remove('active'));
    document.querySelector('.guide-tab[data-gtab="enemies"]').classList.add('active');
    renderGuideTab('enemies');
  }

  function renderGuideTab(tab) {
    const body = document.getElementById('guide-body');
    if (tab === 'enemies') body.innerHTML = renderGuideEnemies();
    else if (tab === 'scoring') body.innerHTML = renderGuideScoring();
    else if (tab === 'tips') body.innerHTML = renderGuideTips();
  }

  function renderGuideEnemies() {
    const enemies = [
      { emoji:'🐹', name:'일반 두더지', desc:'기본 적. 한 번 터치로 처치.', score:100, dmg:10, time:'1.0~2.0초' },
      { emoji:'🐹', name:'빠른 두더지', desc:'빠르게 나타났다 사라짐. 반사신경 테스트!', score:200, dmg:15, time:'0.4~0.8초', stage:3 },
      { emoji:'🌟', name:'골든 두더지', desc:'잡으면 시간 +3초 보너스! 데미지 2배.', score:300, dmg:20, time:'0.8~1.2초', stage:2, special:'시간+3초' },
      { emoji:'🛡️', name:'아머 두더지', desc:'2번 연속 터치해야 처치. 첫 타에 갑옷 금이 감.', score:250, dmg:10, time:'2.0~3.0초', stage:4, special:'2히트 필요' },
      { emoji:'🐭', name:'미니 두더지', desc:'작고 빠름. 데미지가 절반.', score:150, dmg:5, time:'0.6~1.0초', stage:5 },
      { emoji:'🐻', name:'거대 두더지', desc:'3번 연타 필요! HP 게이지가 표시됨.', score:500, dmg:30, time:'1.5~2.5초', stage:7, special:'3히트 필요' },
      { emoji:'💣', name:'폭탄 두더지', desc:'절대 터치 금지! 잡으면 시간 -5초 + 콤보 초기화.', score:0, dmg:0, time:'1.0~1.5초', stage:3, warn:'터치하면 손해' },
      { emoji:'🎭', name:'미끼 두더지', desc:'가짜! 터치하면 콤보 초기화.', score:0, dmg:0, time:'0.8~1.2초', stage:5, warn:'콤보 초기화' },
      { emoji:'💚', name:'힐러 두더지', desc:'놓치면 보스가 HP 20 회복! 반드시 잡기.', score:200, dmg:10, time:'1.5~2.0초', stage:6, warn:'놓치면 보스 회복' },
      { emoji:'🧊', name:'얼음 두더지', desc:'잡으면 주변 칸이 2초간 얼어붙음.', score:200, dmg:10, time:'1.0~1.5초', stage:8, special:'주변 동결' },
      { emoji:'🔴', name:'분열 두더지', desc:'잡으면 주변에 미니 두더지 2마리 추가 스폰.', score:200, dmg:10, time:'1.0초', stage:9, special:'분열 스폰' },
      { emoji:'👤', name:'그림자 두더지', desc:'반투명으로 나타남. 잘 보고 찾아야 함!', score:300, dmg:15, time:'1.0~1.5초', stage:10 },
      { emoji:'👑', name:'왕관 두더지', desc:'고점수! 놓치면 보스 HP 30 대량 회복.', score:1000, dmg:50, time:'0.8~1.0초', stage:8, special:'고점수', warn:'놓치면 보스 대량 회복' },
      { emoji:'🧲', name:'자석 두더지', desc:'잡으면 3초간 적 출현 속도 2배!', score:200, dmg:10, time:'1.5초', stage:11, special:'스폰 가속' }
    ];

    let html = '<div class="guide-section-title">기본 적</div>';
    const basics = enemies.filter(e => !e.warn && !e.special || e.special === '2히트 필요' || e.special === '3히트 필요');
    const specials = enemies.filter(e => e.warn || (e.special && e.special !== '2히트 필요' && e.special !== '3히트 필요'));

    html += renderEnemyList(enemies.slice(0, 6));
    html += '<div class="guide-section-title">기믹 적</div>';
    html += renderEnemyList(enemies.slice(6));
    return html;
  }

  function renderEnemyList(list) {
    return list.map(e => {
      let tags = '';
      if (e.score > 0) tags += `<span class="guide-tag tag-score">${e.score}점</span>`;
      if (e.dmg > 0) tags += `<span class="guide-tag tag-dmg">DMG ${e.dmg}</span>`;
      tags += `<span class="guide-tag tag-time">${e.time}</span>`;
      if (e.special) tags += `<span class="guide-tag tag-special">${e.special}</span>`;
      if (e.warn) tags += `<span class="guide-tag tag-warn">⚠ ${e.warn}</span>`;
      if (e.stage) tags += `<span class="guide-tag tag-time">스테이지 ${e.stage}~</span>`;
      return `<div class="guide-enemy-row">
        <div class="guide-enemy-emoji">${e.emoji}</div>
        <div class="guide-enemy-info">
          <div class="guide-enemy-name">${e.name}</div>
          <div class="guide-enemy-desc">${e.desc}</div>
          <div class="guide-enemy-tags">${tags}</div>
        </div>
      </div>`;
    }).join('');
  }

  function renderGuideScoring() {
    return `
      <div class="guide-section-title">킬 점수</div>
      <div class="guide-score-row"><span>계산식</span><span>적 기본점수 × 콤보 배율</span></div>

      <div class="guide-section-title">콤보 배율</div>
      <div class="guide-score-row"><span>0~4 콤보</span><span>×1.0</span></div>
      <div class="guide-score-row"><span>5~9 콤보</span><span>×1.5</span></div>
      <div class="guide-score-row"><span>10~19 콤보</span><span>×2.0</span></div>
      <div class="guide-score-row"><span>20~29 콤보</span><span>×3.0</span></div>
      <div class="guide-score-row highlight"><span>30+ 콤보</span><span>×4.0</span></div>
      <div class="guide-score-row"><span>콤보 제한시간</span><span>3초</span></div>

      <div class="guide-section-title">클리어 보너스</div>
      <div class="guide-score-row"><span>시간 보너스</span><span>남은 시간 × 100</span></div>
      <div class="guide-score-row highlight"><span>노미스 보너스</span><span>+2,000 (빈칸 0회)</span></div>

      <div class="guide-section-title">등급 판정</div>
      <div class="guide-score-row highlight"><span>S 등급</span><span>클리어 + 시간 50%↑ + 미스 0</span></div>
      <div class="guide-score-row"><span>A 등급</span><span>클리어 + 시간 30%↑</span></div>
      <div class="guide-score-row"><span>B 등급</span><span>클리어</span></div>
      <div class="guide-score-row"><span>C 등급</span><span>실패 + 보스 HP 50%↓</span></div>
      <div class="guide-score-row"><span>F 등급</span><span>실패 + 보스 HP 50%↑</span></div>
    `;
  }

  function renderGuideTips() {
    return `
      <div class="guide-section-title">기본 공략</div>
      <div class="guide-tip"><strong>콤보를 유지하세요!</strong> 30콤보 이상이면 점수 4배. 빈 칸을 누르면 콤보가 끊기니 정확히 노리세요.</div>
      <div class="guide-tip"><strong>💣 폭탄은 무시!</strong> 폭탄을 잡으면 시간 -5초 + 콤보 초기화. 절대 터치하지 마세요.</div>
      <div class="guide-tip"><strong>🎭 미끼도 무시!</strong> 보라색 테두리의 미끼를 잡으면 콤보가 초기화됩니다.</div>
      <div class="guide-tip"><strong>💚 힐러는 반드시 잡기!</strong> 놓치면 보스가 20 HP 회복. 👑 왕관은 놓치면 30 회복!</div>

      <div class="guide-section-title">고급 공략</div>
      <div class="guide-tip"><strong>🌟 골든 우선 처치!</strong> 시간 +3초 보너스 + 데미지 2배. 보이면 바로 터치!</div>
      <div class="guide-tip"><strong>🧊 얼음 주의!</strong> 잡으면 주변 칸이 잠깁니다. 가장자리에서 잡는 게 유리.</div>
      <div class="guide-tip"><strong>🔴 분열은 각오하고!</strong> 잡으면 미니 두더지가 추가 스폰. 바로 추가 콤보 기회!</div>
      <div class="guide-tip"><strong>🧲 자석은 양날의 검!</strong> 잡으면 3초간 적이 2배 빨리 나옴. 콤보를 쌓을 기회이자 위기.</div>

      <div class="guide-section-title">보스전 팁</div>
      <div class="guide-tip"><strong>스테이지 14:</strong> 보스가 8초마다 30 HP 자동회복. 쉬지 말고 공격!</div>
      <div class="guide-tip"><strong>스테이지 15:</strong> 3페이즈 보스전. 후반에 폭탄이 40%로 나오고 보스가 회복합니다. 행/열 잠금에 당황하지 마세요!</div>
      <div class="guide-tip"><strong>S등급 공략:</strong> 시간 절반 이상 남기고 클리어 + 빈 칸 터치 0회. 정확성이 핵심!</div>
    `;
  }

  // ---- Skin Screen ----
  function openSkinScreen() {
    showScreen('skin-screen');
    renderSkinList('enemy');
  }

  async function renderSkinList(category) {
    const list = document.getElementById('skin-list');
    list.innerHTML = '';
    const defs = Skins.getDefinitions()[category];
    const selected = await Skins.getSelected();
    const sel = selected[category];

    for (const skin of defs) {
      const unlocked = skin.unlocked || (await Skins.isUnlocked(category, skin.id));
      const card = document.createElement('div');
      card.className = 'skin-card';
      if (!unlocked) card.classList.add('locked');
      if (skin.id === sel) card.classList.add('selected');
      card.innerHTML = `
        <div class="skin-emoji">${unlocked ? skin.emoji : '🔒'}</div>
        <div class="skin-name">${skin.name}</div>
        <div class="skin-condition">${unlocked ? '보유 중' : skin.condition}</div>
      `;
      if (unlocked) {
        card.addEventListener('click', async () => {
          Audio.sfx.buttonClick();
          await Skins.select(category, skin.id);
          renderSkinList(category);
        });
      }
      list.appendChild(card);
    }
  }

  // ---- Tutorial ----
  let tutorialRespawnTimer = null;

  function spawnTutorialMole() {
    Grid.spawnEnemy(9, EnemyTypes.normal);
    // If mole disappears without being hit, respawn it
    tutorialRespawnTimer = setInterval(() => {
      if (tutorialStep !== 0 || tutorialDone) {
        clearInterval(tutorialRespawnTimer);
        tutorialRespawnTimer = null;
        return;
      }
      const cellState = Grid.getState(9);
      if (!cellState.enemy) {
        Grid.spawnEnemy(9, EnemyTypes.normal);
      }
    }, 500);
  }

  function startTutorial() {
    tutorialStep = 0;
    ui.tutorialOverlay.style.display = '';
    showTutorialStep();

    // Spawn one mole in center
    setTimeout(spawnTutorialMole, 500);
  }

  function showTutorialStep() {
    const steps = [
      { text: '두더지를 탭하세요! 👆', targetCell: 9 },
      { text: '연속으로 맞추면 콤보 UP!', targetCell: -1 },
      { text: '보스의 HP를 0으로 만들면 클리어!', targetCell: -1 }
    ];

    if (tutorialStep >= steps.length) {
      endTutorial();
      return;
    }

    const step = steps[tutorialStep];
    ui.tutorialText.textContent = step.text;

    if (step.targetCell >= 0) {
      const cell = Grid.getCell(step.targetCell);
      if (cell) {
        const rect = cell.getBoundingClientRect();
        ui.tutorialHand.style.left = (rect.left + rect.width / 2 - 20) + 'px';
        ui.tutorialHand.style.top = (rect.top - 45) + 'px';
        ui.tutorialHand.style.display = '';
      }
    } else {
      ui.tutorialHand.style.display = 'none';
    }
  }

  function handleTutorialClick(index) {
    if (tutorialStep === 0) {
      // First hit
      const state = Grid.getState(index);
      if (state.enemy) {
        Grid.hitEnemy(index);
        Audio.sfx.hit();
        Grid.showHitEffect(index, 'normal');
        Grid.spawnParticles(index, '#00ff88');
        showFloatingTextAtCell(index, 'NICE!', 'bonus');

        Boss.takeDamage(10);
        Combo.increment();
        updateBossUIInternal();
        updateComboUI({ count: 1, multiplier: 1.0 });

        tutorialStep = 1;
        showTutorialStep();

        // Spawn more
        setTimeout(() => {
          Grid.spawnEnemy(5, EnemyTypes.normal);
          Grid.spawnEnemy(14, EnemyTypes.normal);
        }, 500);

        setTimeout(() => {
          tutorialStep = 2;
          showTutorialStep();
          setTimeout(() => endTutorial(), 2000);
        }, 2500);
      }
    }
  }

  function endTutorial() {
    tutorialDone = true;
    tutorialStep = -1;
    ui.tutorialOverlay.style.display = 'none';

    const stageData = getStage(currentStage);
    Spawner.start(currentStage, stageData, false);
    startTimer();
    startGameLoop();
  }

  // ---- UI Updates ----
  function updateBossUIInternal() {
    const pct = Boss.getPercent();
    const w = (pct * 100) + '%';
    ui.bossHPFill.style.width = w;
    ui.bossHPTrail.style.width = w;
    ui.bossHPCurrent.textContent = Boss.getHP();
    ui.bossHPMax.textContent = Boss.getMaxHP();

    // Boss reactions
    if (pct <= 0.25) {
      ui.bossPortrait.className = 'boss-portrait panic';
      ui.gameScreen.classList.remove('border-warning');
      ui.gameScreen.classList.add('border-danger');
    } else if (pct <= 0.5) {
      ui.bossPortrait.className = 'boss-portrait hurt';
      ui.gameScreen.classList.add('border-warning');
      ui.gameScreen.classList.remove('border-danger');
    } else {
      ui.bossPortrait.className = 'boss-portrait';
      ui.gameScreen.classList.remove('border-warning', 'border-danger');
    }
  }

  function updateTimerUI() {
    const t = Math.ceil(timeRemaining);
    ui.timerValue.textContent = t;

    // Warning state
    if (t <= 10) {
      ui.hudTimer.classList.add('warning');
    } else {
      ui.hudTimer.classList.remove('warning');
    }

    // Timer bar
    if (ui.timerBarFill) {
      const pct = Math.max(0, Math.min(100, (timeRemaining / totalStageTime) * 100));
      ui.timerBarFill.style.width = pct + '%';
      ui.timerBarTrail.style.width = pct + '%';

      // Color stages
      const colorClass = pct <= 25 ? 'timer-low' : pct <= 50 ? 'timer-mid' : '';
      ui.timerBarFill.className = 'timer-bar-fill' + (colorClass ? ' ' + colorClass : '');
      ui.timerBarTrail.className = 'timer-bar-trail' + (colorClass ? ' ' + colorClass : '');
    }

    // Pulse effect on change
    const delta = timeRemaining - prevTimeRemaining;
    if (delta < -1.5) {
      // Lost time (bomb etc.)
      pulseTimer('timer-hit');
    } else if (delta > 1.5) {
      // Gained time (golden etc.)
      pulseTimer('timer-gain');
    }
    prevTimeRemaining = timeRemaining;
  }

  function pulseTimer(className) {
    ui.hudTimer.classList.remove('timer-hit', 'timer-gain');
    ui.hudTimer.offsetHeight; // reflow
    ui.hudTimer.classList.add(className);
    setTimeout(() => ui.hudTimer.classList.remove(className), 400);
  }

  function updateComboUI(combo) {
    ui.comboCount.textContent = combo.count;
    ui.comboMultiplier.textContent = 'x' + Combo.getMultiplier().toFixed(1);
    if (combo.count > 0) {
      ui.hudCombo.classList.add('active');
      ui.comboCount.style.animation = 'none';
      ui.comboCount.offsetHeight; // reflow
      ui.comboCount.style.animation = 'comboPop 0.2s ease';
    } else {
      ui.hudCombo.classList.remove('active');
    }
  }

  function updateScoreUI() {
    ui.score.textContent = Score.getBaseScore().toLocaleString();
  }

  // ---- Visual Effects ----
  function flashScreen(type) {
    ui.screenFlash.className = 'screen-flash flash-' + type;
    setTimeout(() => { ui.screenFlash.className = 'screen-flash'; }, 400);
  }

  function shakeScreen(intensity) {
    ui.gridWrapper.classList.remove('shake-light', 'shake-heavy');
    ui.gridWrapper.offsetHeight; // reflow
    ui.gridWrapper.classList.add(intensity === 'heavy' ? 'shake-heavy' : 'shake-light');
    setTimeout(() => {
      ui.gridWrapper.classList.remove('shake-light', 'shake-heavy');
    }, 300);
  }

  function showFloatingTextAtCell(cellIndex, text, type) {
    const cell = Grid.getCell(cellIndex);
    if (!cell) return;
    const rect = cell.getBoundingClientRect();
    createFloatingText(rect.left + rect.width / 2, rect.top, text, type);
  }

  function showFloatingTextAtHud(hudElement, text, type) {
    if (!hudElement) return;
    const rect = hudElement.getBoundingClientRect();
    createFloatingText(rect.left + rect.width / 2, rect.bottom + 4, text, type);
  }

  function showFloatingTextPublic(target, text, type) {
    if (target === 'boss') {
      const rect = ui.bossPortrait.getBoundingClientRect();
      createFloatingText(rect.left + rect.width / 2, rect.bottom, text, type);
    }
  }

  function createFloatingText(x, y, text, type) {
    const el = document.createElement('div');
    el.className = 'floating-text ' + type;
    el.textContent = text;
    el.style.left = x + 'px';
    el.style.top = y + 'px';
    el.style.transform = 'translateX(-50%)';
    ui.floatingTexts.appendChild(el);
    setTimeout(() => el.remove(), 800);
  }

  // ---- Helpers ----
  function trackKill(enemyType) {
    // Fire-and-forget: don't await to avoid blocking gameplay
    Storage.update(d => {
      d.stats.totalKills++;
      if (enemyType.id === 'fast') d.stats.fastKills++;
      if (enemyType.id === 'golden') d.stats.goldenKills++;
      if (enemyType.id === 'giant') d.stats.giantKills++;
      if (enemyType.id === 'ice') d.stats.iceKills++;
    });
  }

  function gradeRank(grade) {
    return { S: 5, A: 4, B: 3, C: 2, F: 1 }[grade] || 0;
  }

  async function getNextStage() {
    const save = await Storage.get();
    return Math.min(save.maxStageCleared + 1, 15);
  }

  function getStageTime() {
    const stageData = getStage(currentStage);
    return stageData ? stageData.time : 60;
  }

  // Refresh title data (called when HubGame becomes available after boot)
  async function refreshTitleData() {
    renderPlayerName();
    await renderLeaderboard();
    await updateTitleScreen();
  }

  // Public API
  return {
    init,
    refreshTitleData,
    updateBossUI: updateBossUIInternal,
    showFloatingText: showFloatingTextPublic
  };
})();

// Boot - start immediately, HubGame will be used when available
document.addEventListener('DOMContentLoaded', () => {
  Game.init();

  // Refresh player name & leaderboard once HubGame is injected
  if (!window.HubGame) {
    const hubCheck = setInterval(() => {
      if (window.HubGame) {
        clearInterval(hubCheck);
        Game.refreshTitleData();
      }
    }, 200);
    // Stop polling after 10s
    setTimeout(() => clearInterval(hubCheck), 10000);
  }
});
