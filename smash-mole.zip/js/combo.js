/* ============================================
   Combo System
   ============================================ */
const Combo = (() => {
  let count = 0;
  let maxCombo = 0;
  let lastHitTime = 0;
  const TIMEOUT = 3000; // 3 seconds

  const multiplierTable = [
    { min: 0, max: 4, mult: 1.0 },
    { min: 5, max: 9, mult: 1.5 },
    { min: 10, max: 19, mult: 2.0 },
    { min: 20, max: 29, mult: 3.0 },
    { min: 30, max: Infinity, mult: 4.0 }
  ];

  function getMultiplier() {
    for (const tier of multiplierTable) {
      if (count >= tier.min && count <= tier.max) return tier.mult;
    }
    return 1.0;
  }

  function increment() {
    count++;
    lastHitTime = Date.now();
    if (count > maxCombo) maxCombo = count;
    return { count, multiplier: getMultiplier(), isNewMax: count === maxCombo };
  }

  function reset() {
    const wasActive = count > 0;
    count = 0;
    lastHitTime = 0;
    return wasActive;
  }

  function checkTimeout() {
    if (count > 0 && lastHitTime > 0 && Date.now() - lastHitTime > TIMEOUT) {
      return reset();
    }
    return false;
  }

  function getCount() { return count; }
  function getMaxCombo() { return maxCombo; }
  function resetMax() { maxCombo = 0; }

  function fullReset() {
    count = 0;
    maxCombo = 0;
    lastHitTime = 0;
  }

  return { increment, reset, checkTimeout, getMultiplier, getCount, getMaxCombo, resetMax, fullReset };
})();
