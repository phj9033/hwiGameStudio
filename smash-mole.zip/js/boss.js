/* ============================================
   Boss HP Manager
   ============================================ */
const Boss = (() => {
  let maxHP = 100;
  let currentHP = 100;

  function init(hp) {
    maxHP = hp;
    currentHP = hp;
  }

  function takeDamage(amount) {
    currentHP = Math.max(0, currentHP - amount);
    return currentHP;
  }

  function heal(amount) {
    currentHP = Math.min(maxHP, currentHP + amount);
    return currentHP;
  }

  function isDead() { return currentHP <= 0; }
  function getHP() { return currentHP; }
  function getMaxHP() { return maxHP; }
  function getPercent() { return currentHP / maxHP; }

  function calculateDamage(enemyType, comboMultiplier) {
    return Math.round(enemyType.baseDamage * comboMultiplier * enemyType.damageModifier);
  }

  return { init, takeDamage, heal, isDead, getHP, getMaxHP, getPercent, calculateDamage };
})();
