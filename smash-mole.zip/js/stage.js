/* ============================================
   Stage Definitions & Configuration
   ============================================ */
const Stages = [
  { id:1,  name:'잔디밭의 평화',   bossHP:100,  time:65, maxSimultaneous:3, speedMod:0.05, gimmickRate:0,   newGimmicks:[], tutorial:true,
    desc:'기본 두더지를 잡아보세요!' },
  { id:2,  name:'골드 러시',       bossHP:150,  time:65, maxSimultaneous:3, speedMod:0.12, gimmickRate:0.15, newGimmicks:['golden'],
    desc:'골든 두더지 출현률 UP!' },
  { id:3,  name:'폭발 주의!',     bossHP:200,  time:65, maxSimultaneous:4, speedMod:0.18, gimmickRate:0.2,  newGimmicks:['bomb','fast'],
    desc:'폭탄을 피하세요!' },
  { id:4,  name:'철벽 방어',       bossHP:250,  time:65, maxSimultaneous:4, speedMod:0.22, gimmickRate:0.2,  newGimmicks:['armor'],
    desc:'아머는 두 번 때려야 합니다!' },
  { id:5,  name:'가짜와 진짜',     bossHP:300,  time:70, maxSimultaneous:5, speedMod:0.28, gimmickRate:0.25, newGimmicks:['decoy','mini'],
    desc:'미끼를 조심하세요!' },
  { id:6,  name:'회복의 위협',     bossHP:350,  time:70, maxSimultaneous:5, speedMod:0.32, gimmickRate:0.25, newGimmicks:['healer'],
    desc:'힐러를 놓치면 보스가 회복합니다!' },
  { id:7,  name:'거인의 등장',     bossHP:400,  time:75, maxSimultaneous:5, speedMod:0.38, gimmickRate:0.25, newGimmicks:['giant'],
    desc:'거대 두더지는 3번 연타!' },
  { id:8,  name:'서리의 함정',     bossHP:450,  time:75, maxSimultaneous:6, speedMod:0.42, gimmickRate:0.28, newGimmicks:['ice','crown'],
    desc:'얼음 기믹과 왕관 등장!' },
  { id:9,  name:'분열 카오스',     bossHP:500,  time:80, maxSimultaneous:6, speedMod:0.48, gimmickRate:0.28, newGimmicks:['split'],
    desc:'분열 두더지 대응!' },
  { id:10, name:'그림자 사냥',     bossHP:550,  time:80, maxSimultaneous:7, speedMod:0.50, gimmickRate:0.3,  newGimmicks:['shadow'],
    desc:'반투명 적을 찾아내세요!' },
  { id:11, name:'자석 폭풍',       bossHP:600,  time:85, maxSimultaneous:7, speedMod:0.52, gimmickRate:0.3,  newGimmicks:['magnet'],
    desc:'출몰률 급증 구간!' },
  { id:12, name:'총력전 I',        bossHP:700,  time:85, maxSimultaneous:7, speedMod:0.55, gimmickRate:0.3,  newGimmicks:[],
    desc:'전 기믹 혼합!' },
  { id:13, name:'총력전 II',       bossHP:800,  time:90, maxSimultaneous:8, speedMod:0.58, gimmickRate:0.3,  newGimmicks:[],
    desc:'동시 출몰 최대!' },
  { id:14, name:'최후의 저항',     bossHP:900,  time:90, maxSimultaneous:8, speedMod:0.60, gimmickRate:0.3,  newGimmicks:[],
    desc:'보스 HP 회복 구간!' },
  { id:15, name:'최종 결전',       bossHP:1000, time:95, maxSimultaneous:8, speedMod:0.62, gimmickRate:0.3,  newGimmicks:[],
    desc:'3페이즈 보스전!', isFinalBoss:true }
];

// Stage 15 phase rules
const FinalBossPhases = {
  getPhase(hpPercent) {
    if (hpPercent > 0.667) return 1;
    if (hpPercent > 0.334) return 2;
    return 3;
  },
  getPhaseConfig(phase) {
    switch (phase) {
      case 1: return { maxSimultaneous:6, speedMod:0.52, gimmickRate:0.25, specialRules:[] };
      case 2: return { maxSimultaneous:7, speedMod:0.58, gimmickRate:0.3, specialRules:['rowLock'] };
      case 3: return { maxSimultaneous:8, speedMod:0.65, gimmickRate:0.35, specialRules:['bombRate40','bossRegen'],
                       bombRateOverride:0.4, regenAmount:50, regenInterval:10000 };
      default: return { maxSimultaneous:4, speedMod:0.45, gimmickRate:0.25, specialRules:[] };
    }
  }
};

// Endless mode config (high difficulty, 60s time limit)
const EndlessMode = {
  getConfig(elapsed) {
    const tier = Math.floor(elapsed / 8000); // 8s per tier (aggressive scaling)
    return {
      maxSimultaneous: Math.min(6 + tier, 12),
      speedMod: Math.min(0.45 + 0.1 * tier, 0.9),
      gimmickRate: Math.min(0.28 + tier * 0.04, 0.55)
    };
  }
};

function getStage(stageNum) {
  if (stageNum >= 1 && stageNum <= 15) return Stages[stageNum - 1];
  return null;
}

function getSpawnInterval(stage, stageConfig) {
  const baseInterval = 1.0;
  const mod = stageConfig ? stageConfig.speedMod : (stage * 0.05);
  const variance = 0.25;
  const interval = baseInterval * (1 - Math.min(mod, 0.7)) + (Math.random() * 2 - 1) * variance;
  return Math.max(0.2, interval);
}
