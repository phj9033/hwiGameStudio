/* ============================================
   Skin System
   ============================================ */
const Skins = (() => {
  const definitions = {
    enemy: [
      { id:'classic',  name:'클래식 두더지', emoji:'🐹', condition:'기본 제공', unlocked:true },
      { id:'alien',    name:'우주 외계인',   emoji:'👽', condition:'스테이지 3 클리어', check: s => s.maxStageCleared >= 3 },
      { id:'skeleton', name:'스켈레톤',       emoji:'💀', condition:'스테이지 5 클리어', check: s => s.maxStageCleared >= 5 },
      { id:'cat',      name:'고양이',         emoji:'🐱', condition:'콤보 20회 달성', check: s => s.stats.maxCombo >= 20 },
      { id:'robot',    name:'로봇',           emoji:'🤖', condition:'스테이지 8 클리어', check: s => s.maxStageCleared >= 8 },
      { id:'zombie',   name:'좀비',           emoji:'🧟', condition:'5스테이지 연속 클리어', check: s => s.stats.noGameOverStreak >= 5 },
      { id:'ninja',    name:'닌자',           emoji:'🥷', condition:'빠른 두더지 50마리', check: s => s.stats.fastKills >= 50 },
      { id:'slime',    name:'슬라임',         emoji:'🟢', condition:'총 점수 10,000점', check: s => s.stats.totalScore >= 10000 },
      { id:'penguin',  name:'펭귄',           emoji:'🐧', condition:'얼음 두더지 20마리', check: s => s.stats.iceKills >= 20 },
      { id:'dragon',   name:'용',             emoji:'🐉', condition:'전 스테이지 S랭크', check: s => {
        for (let i = 1; i <= 15; i++) { if (s.stageGrades[i] !== 'S') return false; }
        return true;
      }}
    ],
    hammer: [
      { id:'wood',   name:'나무 망치',   emoji:'🔨', condition:'기본 제공', unlocked:true },
      { id:'rubber', name:'고무 손',     emoji:'✋', condition:'스테이지 2 클리어', check: s => s.maxStageCleared >= 2 },
      { id:'pan',    name:'프라이팬',     emoji:'🍳', condition:'콤보 10회 달성', check: s => s.stats.maxCombo >= 10 },
      { id:'wand',   name:'마법 지팡이', emoji:'🪄', condition:'골든 두더지 30마리', check: s => s.stats.goldenKills >= 30 },
      { id:'laser',  name:'레이저 건',   emoji:'🔫', condition:'스테이지 10 클리어', check: s => s.maxStageCleared >= 10 },
      { id:'fist',   name:'거대 주먹',   emoji:'👊', condition:'거대 두더지 20마리', check: s => s.stats.giantKills >= 20 }
    ],
    grid: [
      { id:'classic',   name:'잔디밭',       emoji:'🌿', condition:'기본 제공', unlocked:true },
      { id:'space',     name:'우주 정거장', emoji:'🌌', condition:'외계인 스킨 해금', check: s => s.unlockedSkins.enemy.includes('alien') },
      { id:'graveyard', name:'묘지',         emoji:'🪦', condition:'스켈레톤 스킨 해금', check: s => s.unlockedSkins.enemy.includes('skeleton') },
      { id:'ocean',     name:'해저',         emoji:'🌊', condition:'스테이지 7 클리어', check: s => s.maxStageCleared >= 7 },
      { id:'lava',      name:'용암 던전',   emoji:'🌋', condition:'총 1,000마리 처치', check: s => s.stats.totalKills >= 1000 }
    ]
  };

  // Sync cache for selected skins (updated on every async load/select)
  let cachedSelected = { enemy: 'classic', hammer: 'wood', grid: 'classic' };

  async function checkUnlocks() {
    const saveData = await Storage.get();
    const newUnlocks = [];

    for (const [category, skins] of Object.entries(definitions)) {
      for (const skin of skins) {
        if (skin.unlocked || saveData.unlockedSkins[category].includes(skin.id)) continue;
        if (skin.check && skin.check(saveData)) {
          newUnlocks.push({ category, ...skin });
          await Storage.update(d => { d.unlockedSkins[category].push(skin.id); });
        }
      }
    }
    return newUnlocks;
  }

  async function isUnlocked(category, id) {
    if (definitions[category].find(s => s.id === id)?.unlocked) return true;
    const save = await Storage.get();
    return save.unlockedSkins[category].includes(id);
  }

  async function getSelected() {
    const save = await Storage.get();
    cachedSelected = save.selectedSkins;
    return save.selectedSkins;
  }

  async function select(category, id) {
    if (!(await isUnlocked(category, id))) return false;
    await Storage.update(d => { d.selectedSkins[category] = id; });
    cachedSelected[category] = id;
    await applySkins();
    return true;
  }

  async function applySkins() {
    const selected = await getSelected();
    document.body.setAttribute('data-grid-skin', selected.grid);
    document.body.setAttribute('data-hammer-skin', selected.hammer);
    document.body.setAttribute('data-enemy-skin', selected.enemy);
  }

  // Synchronous - uses cached value (safe during gameplay)
  function getEnemyEmoji(enemyTypeId) {
    const skinId = cachedSelected.enemy;
    const skinMap = EnemySkins[skinId] || EnemySkins.classic;
    return skinMap[enemyTypeId] || EnemyTypes[enemyTypeId]?.emoji || '🐹';
  }

  function getDefinitions() { return definitions; }

  return { checkUnlocks, isUnlocked, getSelected, select, applySkins, getEnemyEmoji, getDefinitions };
})();
