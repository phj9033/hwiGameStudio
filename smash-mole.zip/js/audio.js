/* ============================================
   Audio Manager - Web Audio API Synthesizer
   ============================================ */
const Audio = (() => {
  let ctx = null;
  let masterGain = null;
  let muted = false;

  function init() {
    if (ctx) return;
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    masterGain = ctx.createGain();
    masterGain.gain.value = 0.3;
    masterGain.connect(ctx.destination);
  }

  function ensureCtx() {
    if (!ctx) init();
    if (ctx.state === 'suspended') ctx.resume();
  }

  function playTone(freq, duration, type = 'square', volume = 0.3, pitchDecay = 0) {
    if (muted) return;
    ensureCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    if (pitchDecay) {
      osc.frequency.exponentialRampToValueAtTime(
        Math.max(freq * pitchDecay, 20), ctx.currentTime + duration
      );
    }
    gain.gain.setValueAtTime(volume, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    osc.connect(gain);
    gain.connect(masterGain);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + duration);
  }

  function playNoise(duration, volume = 0.1) {
    if (muted) return;
    ensureCtx();
    const bufferSize = ctx.sampleRate * duration;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(volume, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    source.connect(gain);
    gain.connect(masterGain);
    source.start();
  }

  // Sound effects
  const sfx = {
    hit() {
      playTone(400, 0.08, 'square', 0.25);
      playTone(600, 0.06, 'square', 0.15);
      playNoise(0.05, 0.08);
    },
    hitCombo(combo) {
      const pitch = 400 + Math.min(combo, 30) * 15;
      playTone(pitch, 0.1, 'square', 0.2);
      playTone(pitch * 1.5, 0.06, 'sine', 0.1);
    },
    hitGolden() {
      playTone(800, 0.15, 'sine', 0.3);
      playTone(1200, 0.1, 'sine', 0.2);
      playTone(1600, 0.08, 'sine', 0.15);
    },
    miss() {
      playTone(200, 0.1, 'sine', 0.1, 0.5);
    },
    bomb() {
      playTone(100, 0.4, 'sawtooth', 0.3, 0.3);
      playNoise(0.3, 0.2);
    },
    armorBreak() {
      playTone(300, 0.1, 'square', 0.2);
      playNoise(0.08, 0.15);
    },
    armorHit() {
      playTone(800, 0.05, 'square', 0.15);
      playTone(200, 0.08, 'triangle', 0.1);
    },
    heal() {
      playTone(300, 0.15, 'sine', 0.15);
      playTone(200, 0.2, 'sine', 0.1);
    },
    comboBreak() {
      playTone(400, 0.1, 'sawtooth', 0.15, 0.2);
      playTone(200, 0.15, 'sawtooth', 0.1, 0.3);
      playNoise(0.15, 0.1);
    },
    freeze() {
      playTone(2000, 0.2, 'sine', 0.15, 0.3);
      playTone(1500, 0.15, 'sine', 0.1);
    },
    crown() {
      playTone(600, 0.1, 'sine', 0.25);
      playTone(800, 0.1, 'sine', 0.25);
      playTone(1000, 0.1, 'sine', 0.25);
      playTone(1200, 0.15, 'sine', 0.2);
    },
    stageClear() {
      const notes = [523, 659, 784, 1047];
      notes.forEach((f, i) => {
        setTimeout(() => playTone(f, 0.2, 'sine', 0.2), i * 100);
      });
    },
    gameOver() {
      playTone(400, 0.2, 'sawtooth', 0.15);
      setTimeout(() => playTone(300, 0.2, 'sawtooth', 0.15), 150);
      setTimeout(() => playTone(200, 0.4, 'sawtooth', 0.2), 300);
    },
    buttonClick() {
      playTone(600, 0.05, 'square', 0.1);
    },
    timerWarning() {
      playTone(800, 0.08, 'square', 0.1);
    },
    unlock() {
      playTone(523, 0.1, 'sine', 0.2);
      setTimeout(() => playTone(659, 0.1, 'sine', 0.2), 80);
      setTimeout(() => playTone(784, 0.15, 'sine', 0.25), 160);
    },
    split() {
      playTone(600, 0.08, 'square', 0.15);
      playTone(900, 0.06, 'square', 0.1);
    },
    magnet() {
      playTone(300, 0.2, 'sine', 0.15);
      playTone(500, 0.15, 'sine', 0.1);
    }
  };

  function toggleMute() { muted = !muted; return muted; }
  function isMuted() { return muted; }

  return { init, sfx, toggleMute, isMuted };
})();
