/* ============================================
   Enemy Type Definitions
   ============================================ */
const EnemyTypes = {
  normal: {
    id: 'normal', name: '일반 두더지', emoji: '🐹', cssClass: 'enemy-normal',
    minTime: 1.0, maxTime: 2.0, baseDamage: 10, baseScore: 100,
    damageModifier: 1.0, minStage: 1, category: 'basic',
    onHit: null, onMiss: null
  },
  fast: {
    id: 'fast', name: '빠른 두더지', emoji: '🐹', cssClass: 'enemy-fast',
    minTime: 0.4, maxTime: 0.8, baseDamage: 15, baseScore: 200,
    damageModifier: 1.0, minStage: 3, category: 'basic',
    onHit: null, onMiss: null
  },
  golden: {
    id: 'golden', name: '골든 두더지', emoji: '🌟', cssClass: 'enemy-golden',
    minTime: 0.8, maxTime: 1.2, baseDamage: 20, baseScore: 300,
    damageModifier: 2.0, minStage: 2, category: 'basic',
    onHit: 'timeBonus', onMiss: null
  },
  armor: {
    id: 'armor', name: '아머 두더지', emoji: '🛡️', cssClass: 'enemy-armor',
    minTime: 2.0, maxTime: 3.0, baseDamage: 10, baseScore: 250,
    damageModifier: 1.0, minStage: 4, category: 'basic',
    hitsRequired: 2, onHit: null, onMiss: null
  },
  mini: {
    id: 'mini', name: '미니 두더지', emoji: '🐭', cssClass: 'enemy-mini',
    minTime: 0.6, maxTime: 1.0, baseDamage: 5, baseScore: 150,
    damageModifier: 0.5, minStage: 5, category: 'basic',
    onHit: null, onMiss: null
  },
  giant: {
    id: 'giant', name: '거대 두더지', emoji: '🐻', cssClass: 'enemy-giant',
    minTime: 1.5, maxTime: 2.5, baseDamage: 30, baseScore: 500,
    damageModifier: 1.0, minStage: 7, category: 'basic',
    hitsRequired: 3, onHit: null, onMiss: null
  },
  bomb: {
    id: 'bomb', name: '폭탄 두더지', emoji: '💣', cssClass: 'enemy-bomb',
    minTime: 1.0, maxTime: 1.5, baseDamage: 0, baseScore: 0,
    damageModifier: 0, minStage: 3, category: 'gimmick',
    onHit: 'bombExplode', onMiss: null // safe to ignore
  },
  healer: {
    id: 'healer', name: '힐러 두더지', emoji: '💚', cssClass: 'enemy-healer',
    minTime: 1.5, maxTime: 2.0, baseDamage: 10, baseScore: 200,
    damageModifier: 1.0, minStage: 6, category: 'gimmick',
    onHit: null, onMiss: 'bossHeal'
  },
  decoy: {
    id: 'decoy', name: '미끼 두더지', emoji: '🎭', cssClass: 'enemy-decoy',
    minTime: 0.8, maxTime: 1.2, baseDamage: 0, baseScore: 0,
    damageModifier: 0, minStage: 5, category: 'gimmick',
    onHit: 'comboReset', onMiss: null
  },
  ice: {
    id: 'ice', name: '얼음 두더지', emoji: '🧊', cssClass: 'enemy-ice',
    minTime: 1.0, maxTime: 1.5, baseDamage: 10, baseScore: 200,
    damageModifier: 1.0, minStage: 8, category: 'gimmick',
    onHit: 'freezeArea', onMiss: null
  },
  split: {
    id: 'split', name: '분열 두더지', emoji: '🔴', cssClass: 'enemy-split',
    minTime: 1.0, maxTime: 1.0, baseDamage: 10, baseScore: 200,
    damageModifier: 1.0, minStage: 9, category: 'gimmick',
    onHit: 'splitSpawn', onMiss: null
  },
  shadow: {
    id: 'shadow', name: '그림자 두더지', emoji: '👤', cssClass: 'enemy-shadow',
    minTime: 1.0, maxTime: 1.5, baseDamage: 15, baseScore: 300,
    damageModifier: 1.0, minStage: 10, category: 'gimmick',
    onHit: null, onMiss: null
  },
  crown: {
    id: 'crown', name: '왕관 두더지', emoji: '👑', cssClass: 'enemy-crown',
    minTime: 0.8, maxTime: 1.0, baseDamage: 50, baseScore: 1000,
    damageModifier: 1.0, minStage: 8, category: 'gimmick',
    onHit: null, onMiss: 'bossHealBig'
  },
  magnet: {
    id: 'magnet', name: '자석 두더지', emoji: '🧲', cssClass: 'enemy-magnet',
    minTime: 1.5, maxTime: 1.5, baseDamage: 10, baseScore: 200,
    damageModifier: 1.0, minStage: 11, category: 'gimmick',
    onHit: 'magnetBoost', onMiss: null
  }
};

// Get available enemy types for a given stage
function getAvailableEnemyTypes(stage) {
  return Object.values(EnemyTypes).filter(e => stage >= e.minStage);
}

// Get weighted random enemy type for a stage
function pickEnemyType(stage, gimmickChance = 0.2) {
  const available = getAvailableEnemyTypes(stage);
  const basics = available.filter(e => e.category === 'basic');
  const gimmicks = available.filter(e => e.category === 'gimmick');

  if (gimmicks.length > 0 && Math.random() < gimmickChance) {
    return gimmicks[Math.floor(Math.random() * gimmicks.length)];
  }
  return basics[Math.floor(Math.random() * basics.length)];
}

// Skin emoji mapping
const EnemySkins = {
  classic: { normal:'🐹', fast:'🐹', golden:'🌟', armor:'🛡️', mini:'🐭', giant:'🐻',
             bomb:'💣', healer:'💚', decoy:'🎭', ice:'🧊', split:'🔴', shadow:'👤', crown:'👑', magnet:'🧲' },
  alien:   { normal:'👽', fast:'👽', golden:'🌟', armor:'🛡️', mini:'👾', giant:'🤖',
             bomb:'💣', healer:'💚', decoy:'🎭', ice:'🧊', split:'🔴', shadow:'👤', crown:'👑', magnet:'🧲' },
  skeleton:{ normal:'💀', fast:'💀', golden:'🌟', armor:'🛡️', mini:'🦴', giant:'☠️',
             bomb:'💣', healer:'💚', decoy:'🎭', ice:'🧊', split:'🔴', shadow:'👤', crown:'👑', magnet:'🧲' },
  cat:     { normal:'🐱', fast:'🐱', golden:'🌟', armor:'🛡️', mini:'🐈', giant:'🦁',
             bomb:'💣', healer:'💚', decoy:'🎭', ice:'🧊', split:'🔴', shadow:'👤', crown:'👑', magnet:'🧲' },
  robot:   { normal:'🤖', fast:'🤖', golden:'🌟', armor:'🛡️', mini:'⚙️', giant:'🦾',
             bomb:'💣', healer:'💚', decoy:'🎭', ice:'🧊', split:'🔴', shadow:'👤', crown:'👑', magnet:'🧲' },
  zombie:  { normal:'🧟', fast:'🧟', golden:'🌟', armor:'🛡️', mini:'🪱', giant:'👹',
             bomb:'💣', healer:'💚', decoy:'🎭', ice:'🧊', split:'🔴', shadow:'👤', crown:'👑', magnet:'🧲' },
  ninja:   { normal:'🥷', fast:'🥷', golden:'🌟', armor:'🛡️', mini:'🐱‍👤', giant:'👺',
             bomb:'💣', healer:'💚', decoy:'🎭', ice:'🧊', split:'🔴', shadow:'👤', crown:'👑', magnet:'🧲' },
  slime:   { normal:'🟢', fast:'🟢', golden:'🌟', armor:'🛡️', mini:'🫧', giant:'🟣',
             bomb:'💣', healer:'💚', decoy:'🎭', ice:'🧊', split:'🔴', shadow:'👤', crown:'👑', magnet:'🧲' },
  penguin: { normal:'🐧', fast:'🐧', golden:'🌟', armor:'🛡️', mini:'🐤', giant:'🦆',
             bomb:'💣', healer:'💚', decoy:'🎭', ice:'🧊', split:'🔴', shadow:'👤', crown:'👑', magnet:'🧲' },
  dragon:  { normal:'🐉', fast:'🐉', golden:'🌟', armor:'🛡️', mini:'🦎', giant:'🐲',
             bomb:'💣', healer:'💚', decoy:'🎭', ice:'🧊', split:'🔴', shadow:'👤', crown:'👑', magnet:'🧲' }
};
