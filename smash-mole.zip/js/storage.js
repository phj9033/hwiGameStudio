/* ============================================
   Storage Manager - HubGame API + localStorage fallback
   ============================================ */
const Storage = (() => {
  const KEY = 'smash_mole_save';

  const defaultData = {
    highScore: 0,
    maxStageCleared: 0,
    stageGrades: {},
    unlockedSkins: { enemy: ['classic'], hammer: ['wood'], grid: ['classic'] },
    selectedSkins: { enemy: 'classic', hammer: 'wood', grid: 'classic' },
    stats: {
      totalKills: 0,
      fastKills: 0,
      goldenKills: 0,
      giantKills: 0,
      iceKills: 0,
      maxCombo: 0,
      totalScore: 0,
      consecutiveClears: 0,
      noGameOverStreak: 0
    }
  };

  async function load() {
    try {
      let data = null;
      if (window.HubGame) {
        data = await window.HubGame.load(KEY);
      } else {
        const raw = localStorage.getItem(KEY);
        data = raw ? JSON.parse(raw) : null;
      }
      if (!data) return structuredClone(defaultData);
      return deepMerge(structuredClone(defaultData), data);
    } catch {
      return structuredClone(defaultData);
    }
  }

  async function save(data) {
    try {
      if (window.HubGame) {
        await window.HubGame.save(KEY, data);
      } else {
        localStorage.setItem(KEY, JSON.stringify(data));
      }
    } catch { /* storage unavailable */ }
  }

  function deepMerge(target, source) {
    for (const key of Object.keys(source)) {
      if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
        if (!target[key]) target[key] = {};
        deepMerge(target[key], source[key]);
      } else {
        target[key] = source[key];
      }
    }
    return target;
  }

  async function get() { return load(); }

  async function update(fn) {
    const data = await load();
    fn(data);
    await save(data);
    return data;
  }

  async function reset() {
    await save(structuredClone(defaultData));
  }

  // Submit score to leaderboard (best score only)
  async function submitBestScore(score) {
    try {
      if (window.HubGame) {
        const prev = (await window.HubGame.load('best')) ?? 0;
        if (score > prev) {
          await window.HubGame.submitScore('best', score);
          await window.HubGame.save('best', score);
        }
      }
    } catch { /* leaderboard unavailable */ }
  }

  // Get leaderboard
  async function getLeaderboard(limit = 10) {
    try {
      return await window.HubGame?.getLeaderboard('best', limit) ?? [];
    } catch {
      return [];
    }
  }

  return { get, update, reset, submitBestScore, getLeaderboard };
})();
