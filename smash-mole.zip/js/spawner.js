/* ============================================
   Spawner - Enemy Spawn Controller
   ============================================ */
const Spawner = (() => {
  let active = false;
  let spawnTimer = null;
  let stageConfig = null;
  let currentStage = 1;
  let isEndless = false;
  let endlessStartTime = 0;
  let magnetBoostEnd = 0;

  // Stage 14 boss regen
  let regenTimer = null;
  // Stage 15 lock timer
  let lockTimer = null;

  function start(stage, config, endless = false) {
    active = true;
    currentStage = stage;
    stageConfig = config;
    isEndless = endless;
    if (endless) endlessStartTime = Date.now();
    magnetBoostEnd = 0;
    scheduleNext();

    // Stage 14: boss regen every 8 seconds
    if (stage === 14) {
      regenTimer = setInterval(() => {
        if (!active) return;
        Boss.heal(30);
        updateBossUI();
        showFloatingText('boss', '+30 HP', 'heal');
      }, 8000);
    }
  }

  function stop() {
    active = false;
    if (spawnTimer) { clearTimeout(spawnTimer); spawnTimer = null; }
    if (regenTimer) { clearInterval(regenTimer); regenTimer = null; }
    if (lockTimer) { clearInterval(lockTimer); lockTimer = null; }
  }

  function scheduleNext() {
    if (!active) return;

    let config = stageConfig;

    // Endless mode dynamic config
    if (isEndless) {
      const elapsed = Date.now() - endlessStartTime;
      config = { ...stageConfig, ...EndlessMode.getConfig(elapsed) };
    }

    // Final boss phase adjustments
    if (currentStage === 15) {
      const phase = FinalBossPhases.getPhase(Boss.getPercent());
      const phaseConfig = FinalBossPhases.getPhaseConfig(phase);
      config = { ...config, ...phaseConfig };

      // Phase 2: row/col lock
      if (phase >= 2 && !lockTimer) {
        lockTimer = setInterval(() => {
          if (!active) return;
          if (Math.random() < 0.5) {
            Grid.lockRow(Math.floor(Math.random() * Grid.ROWS), 2000);
          } else {
            Grid.lockCol(Math.floor(Math.random() * Grid.COLS), 2000);
          }
        }, 3000);
      }

      // Phase 3: boss regen
      if (phase === 3 && !regenTimer) {
        regenTimer = setInterval(() => {
          if (!active) return;
          Boss.heal(50);
          updateBossUI();
          showFloatingText('boss', '+50 HP', 'heal');
        }, 10000);
      }
    }

    const interval = getSpawnInterval(currentStage, config);
    const magnetMod = Date.now() < magnetBoostEnd ? 0.5 : 1;

    spawnTimer = setTimeout(() => {
      if (!active) return;
      spawn(config);
      scheduleNext();
    }, interval * 1000 * magnetMod);
  }

  function spawn(config) {
    const currentCount = Grid.getActiveEnemyCount();
    const maxSimul = config.maxSimultaneous || 3;
    if (currentCount >= maxSimul) return;

    let gimmickRate = config.gimmickRate || 0.2;

    // Stage 15 Phase 3 bomb rate override
    if (config.bombRateOverride && Math.random() < config.bombRateOverride) {
      const cellIdx = Grid.getWeightedEmptyCell();
      if (cellIdx >= 0) Grid.spawnEnemy(cellIdx, EnemyTypes.bomb);
      return;
    }

    const enemyType = pickEnemyType(currentStage, gimmickRate);
    const cellIdx = Grid.getWeightedEmptyCell();
    if (cellIdx >= 0) {
      Grid.spawnEnemy(cellIdx, enemyType);
    }
  }

  function activateMagnetBoost() {
    magnetBoostEnd = Date.now() + 3000;
  }

  function isActive() { return active; }

  return { start, stop, activateMagnetBoost, isActive };
})();

// Helper function referenced by spawner (defined in main.js scope)
function updateBossUI() {
  if (typeof Game !== 'undefined' && Game.updateBossUI) Game.updateBossUI();
}
function showFloatingText(target, text, type) {
  if (typeof Game !== 'undefined' && Game.showFloatingText) Game.showFloatingText(target, text, type);
}
