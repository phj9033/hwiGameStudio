/* ============================================
   Score & Grade System
   ============================================ */
const Score = (() => {
  let baseScore = 0;
  let missCount = 0;
  let enemiesHit = 0;

  function reset() {
    baseScore = 0;
    missCount = 0;
    enemiesHit = 0;
  }

  function addKill(enemyType, comboMultiplier) {
    const points = Math.round(enemyType.baseScore * comboMultiplier);
    baseScore += points;
    enemiesHit++;
    return points;
  }

  function addMiss() { missCount++; }

  function calculateFinal(timeRemaining) {
    const timeBonus = Math.round(timeRemaining * 100);
    const noMissBonus = missCount === 0 ? 2000 : 0;
    return {
      baseScore,
      timeBonus,
      noMissBonus,
      total: baseScore + timeBonus + noMissBonus,
      missCount,
      enemiesHit
    };
  }

  function getGrade(cleared, timeRemaining, totalTime, bossHPPercent) {
    if (cleared) {
      const timePercent = timeRemaining / totalTime;
      if (timePercent >= 0.5 && missCount === 0) return 'S';
      if (timePercent >= 0.3) return 'A';
      return 'B';
    } else {
      if (bossHPPercent <= 0.5) return 'C';
      return 'F';
    }
  }

  function getBaseScore() { return baseScore; }
  function getMissCount() { return missCount; }
  function getEnemiesHit() { return enemiesHit; }

  return { reset, addKill, addMiss, calculateFinal, getGrade, getBaseScore, getMissCount, getEnemiesHit };
})();
